import faiss
import numpy as np
from sentence_transformers import SentenceTransformer

model = SentenceTransformer("all-MiniLM-L6-v2")

file_chunks = []
file_index = None

def store_file_chunks(text, chunk_size=500):
    global file_chunks, file_index

    file_chunks = [
        text[i:i+chunk_size] for i in range(0, len(text), chunk_size)
    ]

    embeddings = model.encode(file_chunks).astype("float32")
    dim = embeddings.shape[1]

    file_index = faiss.IndexFlatL2(dim)
    file_index.add(embeddings)

def search_file_chunks(query, k=3):
    if not file_index:
        return []

    q_vec = model.encode([query]).astype("float32")
    _, ids = file_index.search(q_vec, k)

    return [file_chunks[i] for i in ids[0]]
