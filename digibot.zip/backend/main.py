# backend/main.py

import requests
import subprocess
from fastapi import FastAPI, UploadFile, File, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from fastapi import UploadFile, File
from pypdf import PdfReader
import subprocess


from rag_utils import search_kb

# ======================================
# FASTAPI APP
# ======================================
app = FastAPI(title="DigiBot Backend")

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # dev only
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

MANUAL_FILE = "manual.txt"
@app.post("/upload-kb")
async def upload_kb(file: UploadFile = File(...)):
    try:
        text = ""

        # ---------- PDF ----------
        if file.filename.lower().endswith(".pdf"):
            reader = PdfReader(file.file)
            for page in reader.pages:
                text += page.extract_text() or ""

        # ---------- TEXT ----------
        else:
            content = await file.read()
            text = content.decode("utf-8", errors="ignore")

        if not text.strip():
            raise HTTPException(status_code=400, detail="No readable text found")

        # ---------- APPEND TO MANUAL ----------
        with open("manual.txt", "a", encoding="utf-8") as f:
            f.write("\n\n" + text)

        # ---------- REBUILD FAISS ----------
        subprocess.run(["python", "build_index.py"], check=True)

        return {"message": f"{file.filename} added to knowledge base"}

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ======================================
# DATA MODEL
# ======================================
class ChatRequest(BaseModel):
    query: str


# ======================================
# LOCAL LLM (OLLAMA – PHI)
# ======================================
def call_llm(prompt: str) -> str:
    try:
        res = requests.post(
            "http://localhost:11434/api/generate",
            json={
                "model": "phi",
                "prompt": prompt,
                "stream": False
            },
            timeout=20
        )
        res.raise_for_status()
        return res.json().get("response", "")
    except Exception:
        return ""


# ======================================
# ROUTES
# ======================================
@app.get("/")
def home():
    return {"message": "Backend Running"}


# ======================================
# 🔥 KB UPLOAD API (THIS IS THE MISSING PART)
# ======================================
@app.post("/upload-kb")
async def upload_kb(file: UploadFile = File(...)):
    """
    Uploads a knowledge file and makes it permanent:
    - Appends to manual.txt
    - Rebuilds FAISS index
    """
    try:
        content = await file.read()
        text = content.decode("utf-8", errors="ignore")

        # Append to manual.txt
        with open(MANUAL_FILE, "a", encoding="utf-8") as f:
            f.write("\n")
            f.write(text.strip())
            f.write("\n")

        # Rebuild FAISS index
        subprocess.run(
            ["python", "build_index.py"],
            check=True
        )

        return {
            "status": "KB updated successfully",
            "file": file.filename
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


# ======================================
# CHAT (RAG + LLM)
# ======================================
@app.post("/chat")
def chat(req: ChatRequest):
    try:
        matches = search_kb(req.query, k=2)
        context = "\n".join(matches)

        prompt = f"""
Answer clearly using the information below.

Context:
{context}

Question:
{req.query}
"""

        answer = call_llm(prompt)

        return {
            "reply": answer or "No relevant information found.",
            "sources": matches
        }

    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
