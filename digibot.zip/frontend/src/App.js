import { BrowserRouter, Route, Routes } from "react-router-dom";
import Chatbot from "./pages/Chatbot";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        {/* Default route opens Chatbot */}
        <Route path="/" element={<Chatbot />} />

        {/* Optional: keep /chat working too */}
        <Route path="/chat" element={<Chatbot />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;

