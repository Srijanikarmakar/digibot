import { useEffect, useRef, useState } from "react";
import "../styles/chat.css";

function createNewChat() {
  return {
    id: Date.now(),
    title: "New Chat",
    messages: [],
  };
}

export default function Chatbot() {
  const [chats, setChats] = useState(() => {
    const saved = localStorage.getItem("digibotChats");
    const parsed = saved ? JSON.parse(saved) : [];
    return parsed.length ? parsed : [createNewChat()];
  });

  const [activeId, setActiveId] = useState(chats[0].id);
  const [input, setInput] = useState("");
  const [isTyping, setIsTyping] = useState(false);

  const chatEndRef = useRef(null);
  const fileInputRef = useRef(null);

  const activeChat = chats.find((c) => c.id === activeId);

  // Save chats
  useEffect(() => {
    localStorage.setItem("digibotChats", JSON.stringify(chats));
  }, [chats]);

  // Auto scroll
  useEffect(() => {
    chatEndRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [activeChat?.messages, isTyping]);

  // ================= SEND MESSAGE =================
  async function sendMessage() {
    if (!input.trim()) return;

    const text = input;
    setInput("");

    setChats((prev) =>
      prev.map((chat) =>
        chat.id === activeId
          ? {
              ...chat,
              title:
                chat.messages.length === 0
                  ? text.slice(0, 25)
                  : chat.title,
              messages: [...chat.messages, { sender: "user", text }],
            }
          : chat
      )
    );

    setIsTyping(true);

    try {
      const res = await fetch("http://127.0.0.1:8000/chat", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: text }),
      });

      const data = await res.json();

      setChats((prev) =>
        prev.map((chat) =>
          chat.id === activeId
            ? {
                ...chat,
                messages: [
                  ...chat.messages,
                  { sender: "bot", text: data.reply },
                ],
              }
            : chat
        )
      );
    } catch {
      setChats((prev) =>
        prev.map((chat) =>
          chat.id === activeId
            ? {
                ...chat,
                messages: [
                  ...chat.messages,
                  {
                    sender: "bot",
                    text: "Unable to connect to backend.",
                  },
                ],
              }
            : chat
        )
      );
    } finally {
      setIsTyping(false);
    }
  }

  // ================= FILE UPLOAD =================
  async function handleFileUpload(e) {
    const file = e.target.files[0];
    if (!file) return;

    const formData = new FormData();
    formData.append("file", file);

    await fetch("http://127.0.0.1:8000/upload", {
      method: "POST",
      body: formData,
    });

    setChats((prev) =>
      prev.map((chat) =>
        chat.id === activeId
          ? {
              ...chat,
              messages: [
                ...chat.messages,
                {
                  sender: "bot",
                  text: `File "${file.name}" uploaded. Ask questions about it.`,
                },
              ],
            }
          : chat
      )
    );
  }

  function createChat() {
    const chat = createNewChat();
    setChats((prev) => [chat, ...prev]);
    setActiveId(chat.id);
  }

  function deleteChat(id) {
    const remaining = chats.filter((c) => c.id !== id);
    const updated = remaining.length ? remaining : [createNewChat()];
    setChats(updated);
    setActiveId(updated[0].id);
  }

  return (
    <div className="chat-container">
      {/* SIDEBAR */}
      <div className="sidebar">
        <button onClick={createChat}>+ New Chat</button>

        {chats.map((chat) => (
          <div
            key={chat.id}
            className={`chat-item ${
              chat.id === activeId ? "active" : ""
            }`}
          >
            <span onClick={() => setActiveId(chat.id)}>
              {chat.title}
            </span>
            <button onClick={() => deleteChat(chat.id)}>🗑</button>
          </div>
        ))}
      </div>

      {/* MAIN CHAT */}
      <div className="chat-main">
        <div className="messages">
          {activeChat?.messages.map((msg, i) => (
            <div
              key={i}
              className={`msg ${
                msg.sender === "user" ? "user-msg" : "bot-msg"
              }`}
            >
              {msg.text}
            </div>
          ))}

          {isTyping && (
            <div className="msg bot-msg typing">
              DigiBot is typing…
            </div>
          )}

          <div ref={chatEndRef} />
        </div>

        <input
          type="file"
          ref={fileInputRef}
          style={{ display: "none" }}
          onChange={handleFileUpload}
        />

        <div className="input-area">
          <button onClick={() => fileInputRef.current.click()}>
            +
          </button>

          <input
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            placeholder="Ask DigiBot anything…"
          />

          <button onClick={sendMessage}>Send</button>
        </div>
      </div>
    </div>
  );
}
